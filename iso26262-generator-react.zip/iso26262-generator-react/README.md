# ISO 26262 Work Product Generator (Local AI) – React

Generates **Item Definition**, **Safety Plan**, **HARA** and **Safety Goals** drafts with a local [Ollama](https://ollama.com) model (default `qwen3:8b`) and a local reference library (RAG). Everything runs on your machine: the browser talks only to your Ollama server, and the reference library is stored in the browser (IndexedDB).

## 1. Prerequisites

| What | Version / command |
|---|---|
| Node.js | 20 or newer (`node --version`) |
| Ollama | installed and running (`ollama serve`) |
| Generation model | `ollama pull qwen3:8b` |
| Embedding model (RAG) | `ollama pull nomic-embed-text` |
| Vision model (optional, to read architecture images) | e.g. `ollama pull qwen2.5vl:7b`, then set it in **Settings** |

## 2. Install and run

```bash
npm install
npm run dev
```

Open **http://localhost:5173**.

The dev server forwards `/ollama/*` to `http://localhost:11434`, so there are no CORS problems. If Ollama runs on another machine, start the app with `OLLAMA_HOST=http://<host>:11434 npm run dev`.

Other commands:

```bash
npm test                         # logic tests (ASIL table, validation, prompts, RAG, Excel round-trip) – no browser needed
npm run build && npm run preview # production build, served on http://localhost:4173 (proxy included)
```

If you host the built `dist/` folder on another web server, either proxy `/ollama` to Ollama there, or set the Ollama URL in **Settings** to `http://localhost:11434` and start Ollama with `OLLAMA_ORIGINS=<your app's origin>`.

## 3. How to use

1. **Reference Library** (optional): add your own sample Item Definitions, HARAs, safety goals or method guides (PDF, Word, Excel, text). They are used as style examples.
2. **Home**: pick the work product, upload the system concept and architecture, add assumptions, click **Generate**.
3. **Generate** – guided mode (on by default; switch on the Home page):
   - Sections are generated one at a time (P01, P02 …). Later sections stay **Locked** until the previous one is accepted.
   - Each section is **validated** automatically (empty cells, duplicate or badly formatted IDs, invalid S/E/C values, missing ratings, numbers that do not appear in your inputs, ASIL mismatches, uncovered hazardous events). Errors must be fixed before the section can be accepted.
   - **Accept** – locks in the section and generates the next one, giving the model all accepted sections as context.
   - **Edit** – change cells directly, add or delete rows.
   - **Regenerate** – a fresh draft of this section.
   - **Request changes + Apply Changes** – describe a change in plain words; the model revises the current draft.
   - You can reopen an accepted section; editing it sets it back to Review until you accept it again.
   - With guided mode off, all sections are generated in one run and you accept them afterwards.
4. **Download Excel** at any time; the cover sheet and the *Review status* column record which sections were accepted.
5. When all sections are accepted, **Use as input for …** chains the work products: Item Definition ➜ Safety Plan / HARA ➜ Safety Goals.

## 4. What the tool computes itself (not the model)

- **ASIL** = ISO 26262-3 Table 4 from S/E/C (S0, E0 or C0 → QM; otherwise S+E+C: 10 D, 9 C, 8 B, 7 A, ≤6 QM). It updates live when you change S, E or C.
- **Safety goal ASIL (from HARA)** = highest ASIL of the linked HE-IDs. The model's own proposal is kept in a separate column so you can compare.
- Item Definition "known failure modes" carry **no** ASIL – they are input to the HARA only.

## 5. Project structure

```
src/
  App.jsx                 state, generation flow
  pages/                  Home, Review (edit/export), Library, Settings, About
  components/             Sidebar, Header, FileDrop, EditableTable
  lib/asil.js             ASIL table
  lib/workproducts.js     sections, prompts, JSON schemas, post-processing, per-section generation
  lib/validate.js         automatic checks shown as the validation badge
  lib/ollama.js           Ollama client (structured JSON output, embeddings, vision)
  lib/rag.js, db.js       reference library (chunking, embeddings/keyword search, IndexedDB)
  lib/loaders.js          PDF (pdf.js), Word and Excel text extraction
  lib/office.js           .docx / .xlsx readers (JSZip)
  lib/xlsxWriter.js       styled .xlsx writer (JSZip)
  lib/exporter.js         Excel export layout
tests/logic.test.mjs      node --test
```

Prompts and table columns are in `src/lib/workproducts.js`, so you can adapt them to your company template there.

## 6. Limitations

- An 8B model writes a **draft**. Expect gaps, generic wording and wrong S/E/C ratings; a functional safety engineer must review every row. The tool does not replace ISO 26262-2 confirmation measures.
- Long inputs are cut to the "Max characters per input" setting to fit the model context.
- Qwen3 8B cannot read images. Describe diagrams in the text box, or configure a vision model.
- Only add documents to the reference library that you are allowed to use (for example, no licensed standard text unless your licence permits it).
