import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Requests to /ollama/* are forwarded to the local Ollama server, so the browser never hits CORS limits.
const ollama = {
  '/ollama': {
    target: process.env.OLLAMA_HOST || 'http://localhost:11434',
    changeOrigin: true,
    rewrite: (path) => path.replace(/^\/ollama/, ''),
    timeout: 0,
    proxyTimeout: 0,
  },
};

export default defineConfig({
  plugins: [react()],
  server: { port: 5173, proxy: ollama },
  preview: { port: 4173, proxy: ollama },
  build: { target: 'es2022' },
  optimizeDeps: { esbuildOptions: { target: 'es2022' } },
});
