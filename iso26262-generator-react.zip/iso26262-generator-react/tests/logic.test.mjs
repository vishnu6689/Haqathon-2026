// Run with: node --test tests/   (no browser needed)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { asil, maxAsil } from '../src/lib/asil.js';
import { parseJson } from '../src/lib/ollama.js';
import { WORK_PRODUCTS, schemaFor, postprocess, generate, heAsilMap, toText, displayColumns } from '../src/lib/workproducts.js';
import { ReferenceLibrary, memoryStore, chunkText } from '../src/lib/rag.js';
import { docxText, xlsxText, xlsxSheets } from '../src/lib/office.js';
import { exportWorkbook } from '../src/lib/exporter.js';

const fixture = (f) => readFileSync(new URL(`./fixtures/${f}`, import.meta.url));

test('ASIL matches ISO 26262-3 Table 4 for all 36 combinations', () => {
  const T = { 1: ['QM QM QM', 'QM QM QM', 'QM QM A', 'QM A B'], 2: ['QM QM QM', 'QM QM A', 'QM A B', 'A B C'], 3: ['QM QM A', 'QM A B', 'A B C', 'B C D'] };
  for (const s of [1, 2, 3]) for (const e of [1, 2, 3, 4]) T[s][e - 1].split(' ').forEach((exp, i) => assert.equal(asil(`S${s}`, `E${e}`, `C${i + 1}`), exp, `S${s}E${e}C${i + 1}`));
  assert.equal(asil('S0', 'E4', 'C3'), 'QM'); assert.equal(asil('S3', 'E0', 'C3'), 'QM'); assert.equal(asil('S3', 'E4', 'C0'), 'QM');
  assert.equal(asil('', 'E4', 'C3'), '[check S/E/C]'); assert.equal(asil('S4', 'E4', 'C3'), '[check S/E/C]');
  assert.equal(maxAsil(['A', 'QM', 'C', 'B']), 'C'); assert.equal(maxAsil([undefined]), '');
});

test('parseJson strips thinking and code fences', () => {
  assert.deepEqual(parseJson('<think>hmm</think>```json\n{"rows": []}\n```'), { rows: [] });
  assert.deepEqual(parseJson('Sure! {"rows": [{"a": "1"}]} done'), { rows: [{ a: '1' }] });
  assert.throws(() => parseJson('no json'));
});

test('schema has required columns and enums', () => {
  const s = schemaFor(WORK_PRODUCTS.HARA.sections[0]);
  assert.deepEqual(s.properties.rows.items.properties.S.enum, ['S0', 'S1', 'S2', 'S3']);
  assert.ok(s.properties.rows.items.required.includes('hazardous_event'));
  assert.ok(!displayColumns('Item Definition', WORK_PRODUCTS['Item Definition'].sections[8]).some((c) => c.key.startsWith('asil')), 'no ASIL in Item Definition');
});

test('post-processing computes ASILs deterministically', () => {
  const h = postprocess('HARA', [{ id: 'HE-01', S: 'S3', E: 'E4', C: 'C3' }, { id: 'HE-02', S: 'S2', E: 'E3', C: 'C2' }]);
  assert.equal(h[0].asil, 'D'); assert.equal(h[1].asil, 'A');   // S2+E3+C2 = 7 -> A
  const map = heAsilMap(h);
  const sg = postprocess('Safety Goals', [{ id: 'SG-01', linked_he: 'HE-01, HE-02' }, { id: 'SG-02', linked_he: 'HE-99' }], { heAsil: map });
  assert.equal(sg[0].asil_hara, 'D'); assert.equal(sg[1].asil_hara, '[no matching HE]');
  assert.equal(postprocess('Safety Goals', [{ linked_he: 'HE-01' }])[0].asil_hara, '[needs HARA]');
});

test('reads docx and xlsx (openpyxl shared strings)', async () => {
  const d = await docxText(fixture('sample_concept.docx'));
  assert.match(d, /front radar & camera/); assert.match(d, /F-03 Emergency Braking/);
  const x = await xlsxText(fixture('sample_item_definition.xlsx'));
  assert.match(x, /### Sheet: 3_Functions/); assert.match(x, /Forward Automatic Emergency Braking/);
});

test('full chain with fake model, RAG and Excel round-trip', async () => {
  const fake = {
    calls: 0,
    async chatJson(sys, user, schema) {
      this.calls++;
      const props = schema.properties.rows.items.properties;
      return { rows: [0, 1, 2].map((i) => Object.fromEntries(Object.entries(props).map(([k, v]) => [k, v.enum ? v.enum[v.enum.length - 1 - (i % 2)] : `${k} ${i}`]))) };
    },
    async embed(texts) { return texts.map((t) => [t.length % 7, t.length % 11, 1]); },
  };
  const lib = new ReferenceLibrary(memoryStore());
  const doc = await lib.add({ category: 'item_definition', name: 'ref.xlsx', text: await xlsxText(fixture('sample_item_definition.xlsx')), client: fake, embedModel: 'e' });
  assert.ok(doc.chunks.length > 5 && doc.vectors.length === doc.chunks.length);
  await lib.add({ category: 'hara', name: 'kw.txt', text: 'unintended braking on motorway hazardous event', client: null });
  assert.equal((await lib.search('unintended braking motorway', ['hara'], 1, null, 'e'))[0].file, 'kw.txt');

  const settings = { topK: 2, useEmbeddings: true, embedModel: 'e', maxRows: 5 };
  const id = await generate({ wp: 'Item Definition', inputs: { concept: 'AEB' }, client: fake, library: lib, settings });
  assert.equal(Object.keys(id.sections).length, 10); assert.deepEqual(id.references, ['ref.xlsx']);
  const hara = await generate({ wp: 'HARA', inputs: { upstream: toText('Item Definition', id.sections), upstreamName: 'Item Definition' }, client: fake, library: lib, settings });
  const he = hara.sections.hazardous_events;
  assert.equal(he[0].asil, 'D'); assert.equal(he[1].asil, 'A');  // S3E4C3 -> D, S2E3C2 -> A

  const bytes = await exportWorkbook('HARA', hara.sections, { project: 'Test', model: 'qwen3:8b', references: hara.references });
  const sheets = await xlsxSheets(bytes);
  assert.deepEqual(sheets.map((s) => s.name), ['Cover', 'HARA']);
  const [hdr, r1] = sheets[1].rows;
  assert.equal(r1[hdr.indexOf('ASIL')], 'D');
  assert.equal(fake.calls, 11);
});

test('chunking', () => { assert.equal(chunkText('a '.repeat(3000)).length, 6); });

test('reads HE-ID/ASIL map from an exported HARA workbook', async () => {
  const { readHaraMap } = await import('../src/lib/upstream.js');
  const rows = postprocess('HARA', [{ id: 'HE-01', S: 'S3', E: 'E4', C: 'C3' }, { id: 'HE-02', S: 'S1', E: 'E4', C: 'C3' }]);
  const map = await readHaraMap(await exportWorkbook('HARA', { hazardous_events: rows }, {}));
  assert.deepEqual(map, { 'HE-01': 'D', 'HE-02': 'B' });
});

test('validation flags errors and warnings', async () => {
  const { validateSection } = await import('../src/lib/validate.js');
  const hara = WORK_PRODUCTS.HARA.sections[0];
  const v1 = validateSection('HARA', hara, postprocess('HARA', [{ id: 'HE-01', S: 'S3', E: 'E4', C: '' }, { id: 'HE-01', S: 'S9', E: 'E4', C: 'C3' }]), {});
  assert.ok(v1.errors.some((e) => /Duplicate IDs: HE-01/.test(e)));
  assert.ok(v1.errors.some((e) => /Invalid S value/.test(e)));
  assert.ok(v1.errors.some((e) => /without a complete S\/E\/C/.test(e)));
  const fn = WORK_PRODUCTS['Item Definition'].sections[1];
  const full = (id, extra = {}) => ({ ...Object.fromEntries(fn.columns.map((c) => [c.key, c.key === 'id' ? id : `text ${id}`])), ...extra });
  const v2 = validateSection('Item Definition', fn, [full('F-01'), full('F-02', { behaviour: 'Brakes above 60 km/h within 150 ms' })], { concept: 'operates above 60 km/h' });
  assert.deepEqual(v2.errors, []);
  assert.ok(v2.warnings.some((w) => /150 ms/.test(w) && !/60 km\/h/.test(w)), v2.warnings.join(' | '));
  const v3 = validateSection('Item Definition', fn, [full('F-01'), full('F-02')], {});
  assert.deepEqual(v3, { errors: [], warnings: [], info: [] });
  const sg = WORK_PRODUCTS['Safety Goals'].sections[0];
  const v4 = validateSection('Safety Goals', sg, postprocess('Safety Goals', [{ id: 'SG-01', safety_goal: 'Avoid x', linked_he: 'HE-01', asil_proposed: 'B' }], { heAsil: { 'HE-01': 'D', 'HE-02': 'C' } }), { heAsil: { 'HE-01': 'D', 'HE-02': 'C' } });
  assert.ok(v4.warnings.some((w) => /differs from the HARA for SG-01/.test(w)));
  assert.ok(v4.warnings.some((w) => /not covered by any safety goal: HE-02/.test(w)));
});

test('prompt carries accepted sections and the change request', async () => {
  const { buildPrompt, acceptedContext } = await import('../src/lib/workproducts.js');
  const spec = WORK_PRODUCTS['Item Definition'];
  const ctx = acceptedContext('Item Definition', { purpose: [{ aspect: 'Purpose', description: 'Mitigate front collisions' }] }, ['purpose']);
  assert.match(ctx, /Purpose & Item Boundary[\s\S]*Mitigate front collisions/);
  const p = buildPrompt('Item Definition', spec.sections[1], {}, [], 8, { accepted: ctx, revise: { request: 'Add a torque suppression function', rows: [{ id: 'F-01' }] } });
  assert.match(p, /ALREADY ACCEPTED[\s\S]*Mitigate front collisions/);
  assert.match(p, /REVISION REQUEST[\s\S]*Add a torque suppression function[\s\S]*"id": "F-01"/);
  assert.ok(WORK_PRODUCTS['Safety Plan'].sections.length === 7 && WORK_PRODUCTS['Safety Plan'].upstream === 'Item Definition');
});
