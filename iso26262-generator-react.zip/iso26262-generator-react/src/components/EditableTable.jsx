import { useLayoutEffect, useRef } from 'react';

function AutoText({ value, onChange }) {
  const ref = useRef(null);
  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight + 2, 220)}px`;
  }, [value]);
  return <textarea ref={ref} rows={1} value={value} onChange={(e) => onChange(e.target.value)} />;
}

const ASIL_CLASS = { QM: 'asil-qm', A: 'asil-a', B: 'asil-b', C: 'asil-c', D: 'asil-d' };

export default function EditableTable({ columns, rows, onChange }) {
  const set = (i, key, value) => onChange(rows.map((r, j) => (j === i ? { ...r, [key]: value } : r)));
  const blank = () => Object.fromEntries(columns.map((c) => [c.key, '']));
  return (
    <div className="table-wrap">
      <table className="grid">
        <thead>
          <tr>{columns.map((c) => <th key={c.key} className={c.locked ? 'locked' : ''}>{c.header}{c.locked && <span title="Computed by the tool"> 🔒</span>}</th>)}<th /></tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {columns.map((c) => (
                <td key={c.key} className={c.enum || c.locked ? 'narrow' : c.key === 'id' ? 'id' : ''}>
                  {c.locked ? (
                    <span className={`asil ${ASIL_CLASS[r[c.key]] || 'asil-check'}`}>{r[c.key]}</span>
                  ) : c.enum ? (
                    <select value={r[c.key] ?? ''} onChange={(e) => set(i, c.key, e.target.value)} aria-label={`${c.header} row ${i + 1}`}>
                      <option value="">–</option>
                      {c.enum.map((o) => <option key={o}>{o}</option>)}
                    </select>
                  ) : (
                    <AutoText value={r[c.key] ?? ''} onChange={(v) => set(i, c.key, v)} />
                  )}
                </td>
              ))}
              <td className="narrow"><button className="icon-btn" title="Delete row" onClick={() => onChange(rows.filter((_, j) => j !== i))}>🗑️</button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn ghost small" onClick={() => onChange([...rows, blank()])}>＋ Add row</button>
    </div>
  );
}
