const ASIL_CLASS = { QM: 'asil-qm', A: 'asil-a', B: 'asil-b', C: 'asil-c', D: 'asil-d' };

/** Read-only view of a section. Two-column "aspect / description" sections are shown as prose blocks. */
export default function ViewTable({ columns, rows }) {
  const data = columns.filter((c) => c.key !== 'review');
  if (data.length === 2 && ['aspect', 'description'].every((k) => data.some((c) => c.key === k))) {
    return (
      <div className="prose-view">
        {rows.map((r, i) => (
          <div key={i} className="prose-block"><div className="prose-label">{r.aspect}</div><p>{r.description}</p></div>
        ))}
      </div>
    );
  }
  return (
    <div className="table-wrap view">
      <table className="grid">
        <thead><tr>{data.map((c) => <th key={c.key}>{c.header}</th>)}</tr></thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {data.map((c) => (
                <td key={c.key} className={c.enum || c.locked ? 'narrow' : c.key === 'id' ? 'id' : ''}>
                  {c.locked ? <span className={`asil ${ASIL_CLASS[r[c.key]] || 'asil-check'}`}>{r[c.key]}</span>
                    : String(r[c.key] ?? '').trim() ? <span className="cell-text">{r[c.key]}</span> : <span className="cell-empty">—</span>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
