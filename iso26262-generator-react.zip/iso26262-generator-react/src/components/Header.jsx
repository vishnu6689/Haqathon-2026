export default function Header({ model }) {
  return (
    <header className="app-header">
      <div className="app-header-shield">🛡️</div>
      <div>
        <h1>ISO 26262 Work Product Generator (Local AI)</h1>
        <p>Generate Item Definition, Safety Plan, HARA and Safety Goals using Local Ollama + {model} with RAG</p>
      </div>
    </header>
  );
}
