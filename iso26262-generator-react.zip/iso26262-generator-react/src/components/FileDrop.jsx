import { useRef, useState } from 'react';

const ICON = { pdf: '📕', docx: '📘', xlsx: '📗', png: '🖼️', jpg: '🖼️', jpeg: '🖼️', txt: '📄', md: '📄' };
const ext = (n) => n.split('.').pop().toLowerCase();
const size = (b) => (b > 1e6 ? `${(b / 1e6).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1e3))} KB`);

export default function FileDrop({ icon, title, subtitle, accept, files, onChange, multiple = true, children, testId }) {
  const input = useRef(null);
  const [over, setOver] = useState(false);
  const allowed = accept.split(',').map((a) => a.trim().replace('.', ''));
  const add = (list) => {
    const picked = [...list].filter((f) => allowed.includes(ext(f.name)));
    if (!picked.length) return;
    onChange(multiple ? [...files.filter((f) => !picked.some((p) => p.name === f.name)), ...picked] : picked.slice(0, 1));
  };
  return (
    <div className="card">
      <div className="card-head">
        <span className="card-icon">{icon}</span>
        <div><div className="card-title">{title}</div><div className="card-sub">{subtitle}</div></div>
      </div>
      <div
        className={`drop ${over ? 'over' : ''}`} data-testid={testId}
        onClick={() => input.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); add(e.dataTransfer.files); }}
      >
        <input ref={input} type="file" hidden multiple={multiple} accept={accept} onChange={(e) => { add(e.target.files); e.target.value = ''; }} />
        <span>Drop files here or <u>browse</u></span>
        <small>{accept.replaceAll('.', '').toUpperCase().replaceAll(',', ', ')}</small>
      </div>
      {files.map((f) => (
        <div className="file-row" key={f.name}>
          <span className="file-icon">{ICON[ext(f.name)] || '📄'}</span>
          <div className="file-meta"><span>{f.name}</span><small>{size(f.size)}</small></div>
          <button className="icon-btn" title="Remove" onClick={() => onChange(files.filter((x) => x !== f))}>✕</button>
        </div>
      ))}
      {children}
    </div>
  );
}
