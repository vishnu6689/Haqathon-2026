const NAV = [
  { id: 'Home', icon: '🏠' },
  { id: 'Generate', icon: '✨', label: 'Generate' },
  { id: 'Reference Library', icon: '📚' },
  { id: 'Settings', icon: '⚙️' },
  { id: 'About', icon: 'ℹ️' },
];

export default function Sidebar({ page, setPage, settings, results, busy }) {
  const done = Object.keys(results);
  return (
    <aside className="sidebar">
      <div className="brand"><span className="brand-shield">🛡️</span><div><b>ISO 26262</b><small>Work Product Generator</small></div></div>
      <nav>
        {NAV.map((n) => (
          <button key={n.id} className={`nav-item ${page === n.id ? 'active' : ''}`} onClick={() => setPage(n.id)}>
            <span className="nav-icon">{n.icon}</span>{n.label || n.id}
            {n.id === 'Generate' && done.length > 0 && <span className="nav-badge">{done.length}</span>}
          </button>
        ))}
      </nav>
      <div className="sidebar-foot">
        <div><span className={`dot ${busy ? 'busy' : ''}`} /> {busy ? 'Generating …' : 'Idle'}</div>
        <div>Model: <b>{settings.model}</b></div>
        <div className="muted">Ollama: {settings.ollamaUrl}</div>
        <div className="muted">Generated: {done.length ? done.join(', ') : 'none yet'}</div>
      </div>
    </aside>
  );
}
