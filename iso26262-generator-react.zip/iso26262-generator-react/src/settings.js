export const DEFAULT_SETTINGS = {
  ollamaUrl: '/ollama',          // proxied to http://localhost:11434 by Vite
  model: 'qwen3:8b',
  embedModel: 'nomic-embed-text',
  visionModel: '',               // e.g. 'qwen2.5vl:7b' to read architecture images
  useEmbeddings: true,
  guided: true,                  // review and accept each section before the next one is generated
  temperature: 0.2,
  numCtx: 16384,
  topK: 4,
  maxRows: 12,
  maxInputChars: 12000,
};

const KEY = 'wpg-settings';

export function loadSettings() {
  try { return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { return { ...DEFAULT_SETTINGS }; }
}

export function saveSettings(s) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* storage unavailable – keep in memory */ }
}
