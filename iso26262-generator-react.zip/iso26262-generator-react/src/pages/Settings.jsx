import { useState } from 'react';
import { OllamaClient } from '../lib/ollama.js';
import { DEFAULT_SETTINGS } from '../settings.js';

const FIELDS = [
  ['ollamaUrl', 'Ollama URL', 'text', '"/ollama" uses the Vite proxy to http://localhost:11434'],
  ['model', 'Generation model', 'text', 'e.g. qwen3:8b'],
  ['embedModel', 'Embedding model', 'text', 'e.g. nomic-embed-text'],
  ['visionModel', 'Vision model for diagrams (optional)', 'text', 'e.g. qwen2.5vl:7b – leave empty to disable'],
  ['numCtx', 'Context length (num_ctx)', 'number', 'Larger needs more GPU / RAM'],
  ['maxInputChars', 'Max characters per input', 'number', 'Inputs are cut to this length'],
];

export default function Settings({ settings, setSettings }) {
  const [draft, setDraft] = useState(settings);
  const [test, setTest] = useState(null);
  const [saved, setSaved] = useState(false);

  async function testConnection() {
    setTest({ state: 'busy', text: 'Connecting …' });
    try {
      const models = await new OllamaClient({ baseUrl: draft.ollamaUrl }).listModels();
      const check = [draft.model, draft.embedModel, draft.visionModel].filter(Boolean)
        .map((m) => ({ m, ok: models.some((x) => x === m || x === `${m}:latest`) }));
      setTest({ state: 'ok', text: `Connected – ${models.length} models installed.`, check });
    } catch (e) { setTest({ state: 'err', text: e.message }); }
  }

  return (
    <section className="page">
      <h2 className="step-title">Settings</h2>
      <p className="step-sub">Saved in this browser</p>
      <div className="card">
        <div className="grid-2">
          {FIELDS.map(([key, label, type, hint]) => (
            <label className="field" key={key}><span>{label}</span>
              <input type={type} value={draft[key]} onChange={(e) => setDraft({ ...draft, [key]: type === 'number' ? Number(e.target.value) : e.target.value })} />
              <small>{hint}</small></label>
          ))}
        </div>
        <div className="actions">
          <button className="btn primary" onClick={() => { setSettings(draft); setSaved(true); setTimeout(() => setSaved(false), 2000); }}>💾 Save settings</button>
          <button className="btn secondary" onClick={testConnection}>🔌 Test connection</button>
          <button className="btn ghost" onClick={() => setDraft({ ...DEFAULT_SETTINGS })}>Reset to defaults</button>
          {saved && <span className="hint ok">Saved.</span>}
        </div>
        {test && (
          <div className={`hint ${test.state === 'err' ? 'warn' : 'ok'}`}>
            {test.text}
            {test.check?.map(({ m, ok }) => <div key={m}>{ok ? '✅' : '⚠️'} {m} {ok ? 'installed' : `not found – run: ollama pull ${m}`}</div>)}
          </div>
        )}
      </div>
    </section>
  );
}
