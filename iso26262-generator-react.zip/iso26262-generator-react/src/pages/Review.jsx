import { useEffect, useState } from 'react';
import EditableTable from '../components/EditableTable.jsx';
import ViewTable from '../components/ViewTable.jsx';
import { WORK_PRODUCTS, displayColumns, sectionCode } from '../lib/workproducts.js';
import { exportFileName, exportWorkbook } from '../lib/exporter.js';

const STATUS = {
  accepted: { label: '✓ Accepted', cls: 'st-accepted' },
  review: { label: '▶ Review', cls: 'st-review' },
  generating: { label: 'Generating …', cls: 'st-generating' },
  locked: { label: '○ Locked', cls: 'st-locked' },
  error: { label: '⚠ Error', cls: 'st-error' },
};

function Validation({ v }) {
  const [open, setOpen] = useState(false);
  if (!v) return null;
  const { errors, warnings, info } = v;
  const kind = errors.length ? 'bad' : warnings.length ? 'warn' : 'ok';
  const label = errors.length ? `✕ Validation failed – ${errors.length} error${errors.length > 1 ? 's' : ''}${warnings.length ? `, ${warnings.length} warning${warnings.length > 1 ? 's' : ''}` : ''}`
    : warnings.length ? `⚠ Validation passed with ${warnings.length} warning${warnings.length > 1 ? 's' : ''}` : '✓ Validation passed';
  const items = [...errors.map((t) => ['bad', t]), ...warnings.map((t) => ['warn', t]), ...info.map((t) => ['info', t])];
  return (
    <div className="validation">
      <button className={`val-badge ${kind}`} onClick={() => setOpen(!open)} disabled={!items.length}>
        {label}{items.length > 0 && <span className="val-toggle">{open ? ' ▲' : ' ▼'}</span>}
      </button>
      {open && <ul className="val-list">{items.map(([k, t], i) => <li key={i} className={k}>{t}</li>)}</ul>}
    </div>
  );
}

export default function Review({ results, actions, onUseAsInput, goHome }) {
  const available = Object.keys(WORK_PRODUCTS).filter((w) => results[w]);
  const [wpSel, setWp] = useState(null);
  const wp = results[wpSel] ? wpSel : available[available.length - 1];
  const res = results[wp];
  const spec = wp ? WORK_PRODUCTS[wp] : null;

  // follow the section that needs attention unless the user picked one
  const focus = spec?.sections.find((s) => ['generating', 'review', 'error'].includes(res.steps[s.id]?.status))?.id;
  const [picked, setPicked] = useState(null);
  const [editing, setEditing] = useState(false);
  const [request, setRequest] = useState('');
  const [busy, setBusy] = useState(false);
  // when the next section needs attention, move to it – but not while the user is working on the section they picked
  useEffect(() => {
    if (focus && focus === picked) return;
    setPicked(null); setEditing(false); setRequest('');
  }, [focus, wp]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!available.length) {
    return (
      <section className="page">
        <h2 className="step-title">2. Review, Edit & Accept</h2>
        <div className="empty">Nothing generated yet. <button className="link" onClick={goHome}>Go to Home</button>, add your inputs and click Generate.</div>
      </section>
    );
  }

  const ids = spec.sections.map((s) => s.id);
  const accepted = ids.filter((id) => res.steps[id].status === 'accepted').length;
  const allDone = accepted === ids.length;
  const currentId = picked && res.steps[picked]?.status !== 'locked' ? picked : focus || (allDone ? null : ids.find((id) => res.steps[id].status !== 'locked'));
  const index = ids.indexOf(currentId);
  const section = spec.sections[index];
  const step = currentId ? res.steps[currentId] : null;
  const rows = currentId ? res.sections[currentId] || [] : [];
  const generating = step?.status === 'generating';
  const anyGenerating = ids.some((id) => res.steps[id].status === 'generating');
  const downstream = Object.entries(WORK_PRODUCTS).filter(([, s]) => s.upstream === wp).map(([name]) => name);

  async function download() {
    setBusy(true);
    try {
      const bytes = await exportWorkbook(wp, res.sections, { ...res.meta, accepted: `${accepted} of ${ids.length}` });
      const url = URL.createObjectURL(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
      const a = Object.assign(document.createElement('a'), { href: url, download: exportFileName(res.meta.project, wp) });
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } finally { setBusy(false); }
  }

  const select = (id) => { if (res.steps[id].status !== 'locked') { setPicked(id); setEditing(false); setRequest(''); } };

  return (
    <section className="page">
      <h2 className="step-title">2. Review, Edit & Accept</h2>
      <p className="step-sub">{res.guided ? 'Each section is generated after the previous one is accepted, using the accepted sections as context.' : 'All sections were generated in one run – review and accept each one.'}</p>

      {available.length > 1 && (
        <div className="wp-picker">
          {available.map((w) => (
            <label key={w} className={`wp-option ${w === wp ? 'selected' : ''}`}>
              <input type="radio" name="view-wp" checked={w === wp} onChange={() => { setWp(w); setPicked(null); }} />
              <span className="radio" /> <span>{WORK_PRODUCTS[w].icon} {w}</span>
            </label>
          ))}
        </div>
      )}

      <div className="card progress-list">
        <div className="progress-head">
          <span className="count-circle">{accepted}/{ids.length}</span>
          <div><b>Progress</b> — {accepted} of {ids.length} section{ids.length > 1 ? 's' : ''} accepted</div>
        </div>
        {spec.sections.map((s, i) => {
          const st = res.steps[s.id].status;
          return (
            <button key={s.id} className={`step-row ${s.id === currentId ? 'current' : ''} ${st}`} onClick={() => select(s.id)} disabled={st === 'locked'}>
              <span className="step-code">{sectionCode(i)}</span>
              <span className="step-name">{s.name}</span>
              <span className={`step-status ${STATUS[st].cls}`}>{st === 'generating' && <span className="spinner" />}{STATUS[st].label}</span>
            </button>
          );
        })}
      </div>

      {section && (
        <div className="card step-card">
          <div className="step-card-head">
            <span className="num-circle">{index + 1}</span>
            <h3>{sectionCode(index)} — {section.name}</h3>
            <span className={`pill ${STATUS[step.status].cls}`}>{STATUS[step.status].label}</span>
          </div>

          {generating ? (
            <div className="generating">
              <span className="spinner big" />
              <div><b>Generating {section.name} …</b><div className="hint">{res.guided && index > 0 ? 'Using the accepted sections as context.' : 'This can take a minute with a local model.'}</div></div>
              <button className="btn ghost small" onClick={actions.stop}>■ Stop</button>
            </div>
          ) : (
            <>
              {step.error && <div className="alert">{step.error}</div>}
              <Validation v={step.validation} />
              {rows.length > 0 && (editing
                ? <EditableTable columns={displayColumns(wp, section)} rows={rows} onChange={(r) => actions.editRows(wp, section.id, r)} />
                : <ViewTable columns={displayColumns(wp, section)} rows={rows} />)}

              <label className="field request">
                <span>Request changes <small>— Optional</small></span>
                <textarea rows={2} value={request} onChange={(e) => setRequest(e.target.value)} placeholder="Describe a specific change to apply to this draft…" />
              </label>
              <div className="step-actions">
                <button className="btn accept" disabled={!rows.length || step.status === 'accepted' || step.validation?.errors.length > 0 || anyGenerating}
                  title={step.validation?.errors.length ? 'Fix the validation errors first (Edit or Apply Changes)' : ''}
                  onClick={() => { setEditing(false); actions.accept(wp, section.id); }}>✓ Accept</button>
                <button className="btn ghost" disabled={!rows.length || anyGenerating} onClick={() => setEditing(!editing)}>{editing ? '✓ Done editing' : '✎ Edit'}</button>
                <button className="btn ghost" disabled={anyGenerating} onClick={() => { setEditing(false); actions.regenerate(wp, section.id); }}>↻ Regenerate</button>
                <button className="btn ghost" disabled={!request.trim() || !rows.length || anyGenerating}
                  onClick={() => { setEditing(false); actions.applyChanges(wp, section.id, request.trim()); setRequest(''); }}>⚙ Apply Changes</button>
              </div>
            </>
          )}
        </div>
      )}

      {allDone && (
        <div className="card done-card">
          <div className="done-title">🎉 All {ids.length} sections accepted</div>
          <p className="hint">The {wp} draft is complete. It still needs the review and confirmation measures required by ISO 26262-2.</p>
        </div>
      )}

      <div className="actions">
        <button className="btn primary" onClick={download} disabled={busy || !accepted && !Object.keys(res.sections).length}>
          ⬇️ {busy ? 'Preparing …' : allDone ? 'Download Excel' : `Download draft Excel (${accepted}/${ids.length} accepted)`}
        </button>
        {allDone && downstream.map((d) => (
          <button key={d} className="btn secondary" onClick={() => onUseAsInput(wp, d)}>➡️ Use as input for {d}</button>
        ))}
      </div>
    </section>
  );
}
