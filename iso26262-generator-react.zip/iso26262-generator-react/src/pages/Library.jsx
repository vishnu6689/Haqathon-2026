import { useState } from 'react';
import FileDrop from '../components/FileDrop.jsx';
import { CATEGORIES } from '../lib/rag.js';
import { extractText } from '../lib/loaders.js';

export default function Library({ library, docs, refresh, client, settings }) {
  const [pending, setPending] = useState({});
  const [status, setStatus] = useState('');

  async function add(category) {
    const files = pending[category] || [];
    for (const f of files) {
      setStatus(`Indexing ${f.name} …`);
      const text = await extractText(f, 400000);
      const doc = await library.add({ category, name: f.name, text, client: settings.useEmbeddings ? client : null, embedModel: settings.embedModel });
      setStatus(`${f.name}: ${doc.chunks.length} chunks indexed (${doc.note})`);
    }
    setPending((p) => ({ ...p, [category]: [] }));
    refresh();
  }

  async function remove(id) { await library.remove(id); refresh(); }

  return (
    <section className="page">
      <h2 className="step-title">Reference Library</h2>
      <p className="step-sub">Documents retrieved as style and structure examples during generation (RAG). Stored only in this browser (IndexedDB).</p>
      <div className="disclaimer">Only add documents you are allowed to use, such as your own company templates. Do not add licensed standard text unless your licence permits it.</div>
      {status && <div className="hint ok">{status}</div>}
      <div className="grid-2">
        {Object.entries(CATEGORIES).map(([key, c]) => {
          const list = docs.filter((d) => d.category === key);
          return (
            <FileDrop key={key} testId={`lib-${key}`} icon={c.icon} title={`${c.label} (${list.length})`} subtitle={c.bullets.join(' · ')}
              accept=".pdf,.docx,.xlsx,.txt,.md" files={pending[key] || []} onChange={(fs) => setPending((p) => ({ ...p, [key]: fs }))}>
              {(pending[key] || []).length > 0 && <button className="btn primary small" onClick={() => add(key)}>Add to library</button>}
              {list.map((d) => (
                <div className="file-row indexed" key={d.id}>
                  <span className="file-icon">✅</span>
                  <div className="file-meta"><span>{d.name}</span><small>{d.chunks.length} chunks · {d.note}</small></div>
                  <button className="icon-btn" title="Delete from library" onClick={() => remove(d.id)}>🗑️</button>
                </div>
              ))}
            </FileDrop>
          );
        })}
      </div>
    </section>
  );
}
