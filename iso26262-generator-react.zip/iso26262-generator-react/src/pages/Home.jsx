import { useEffect, useState } from 'react';
import FileDrop from '../components/FileDrop.jsx';
import { WORK_PRODUCTS } from '../lib/workproducts.js';
import { CATEGORIES } from '../lib/rag.js';
import { isImage } from '../lib/loaders.js';

const PLACEHOLDER = '• Vehicle type: Passenger car\n• Operating environment: Urban, highway\n• Target speed: 0 – 130 km/h\n• Relevant standards: ISO 26262, ISO 21448\n• Customer requirement: Automatic emergency braking for frontal collisions';

function Thumb({ file }) {
  const [url, setUrl] = useState('');
  useEffect(() => { const u = URL.createObjectURL(file); setUrl(u); return () => URL.revokeObjectURL(u); }, [file]);
  return url ? <img className="thumb" src={url} alt={file.name} /> : null;
}

export default function Home({ form, updateForm, settings, setSettings, job, error, onGenerate, onStop, results, lastInputs, libDocs, goLibrary, sessionHeAsil, busy }) {
  const spec = WORK_PRODUCTS[form.wp];
  const images = form.archFiles.filter((f) => isImage(f.name));
  const upName = spec.upstream;
  const hasSession = upName && results[upName];
  const useSession = hasSession && form.useSession[form.wp] !== false;
  const setUse = (key, v) => updateForm({ useSession: { ...form.useSession, [key]: v } });

  return (
    <section className="page">
      <h2 className="step-title">1. Project Inputs</h2>
      <p className="step-sub">Provide system information to generate ISO 26262 work products</p>

      <label className="field">
        <span>Project / item name</span>
        <input value={form.project} onChange={(e) => updateForm({ project: e.target.value })} placeholder="e.g. Forward AEB – passenger car M1" />
      </label>

      <div className="label">Select Work Product</div>
      <div className="wp-picker" role="radiogroup">
        {Object.entries(WORK_PRODUCTS).map(([name, wp]) => (
          <label key={name} className={`wp-option ${form.wp === name ? 'selected' : ''}`}>
            <input type="radio" name="wp" checked={form.wp === name} onChange={() => updateForm({ wp: name })} />
            <span className="radio" /> <span>{wp.icon} {name}</span>
          </label>
        ))}
      </div>

      <div className="grid-2">
        <FileDrop testId="drop-concept" icon="📄" title="System Concept / Function" subtitle="Upload system description, functional specification, etc."
          accept=".pdf,.docx,.xlsx,.txt,.md" files={form.conceptFiles} onChange={(conceptFiles) => updateForm({ conceptFiles })}>
          {lastInputs && !form.conceptFiles.length && (
            <label className="check">
              <input type="checkbox" checked={form.useSession.reusePrev !== false} onChange={(e) => setUse('reusePrev', e.target.checked)} />
              Reuse inputs from the previous run ({lastInputs.files.join(', ') || 'text only'})
            </label>
          )}
        </FileDrop>
        <FileDrop testId="drop-arch" icon="🧩" title="System Architecture" subtitle="Upload architecture diagrams or documents"
          accept=".png,.jpg,.jpeg,.pdf,.docx,.xlsx,.txt,.md" files={form.archFiles} onChange={(archFiles) => updateForm({ archFiles })}>
          {images.length > 0 && (
            <>
              <div className="thumbs">{images.map((f) => <Thumb key={f.name} file={f} />)}</div>
              {!settings.visionModel && <div className="hint warn">⚠️ {settings.model} cannot read images. Describe the diagram below, or set a vision model in Settings.</div>}
            </>
          )}
          <textarea className="small-area" value={form.archText} onChange={(e) => updateForm({ archText: e.target.value })}
            placeholder="Optional: describe ECUs, sensors, actuators and the main signals between them…" rows={3} />
        </FileDrop>
      </div>

      {upName && (
        <div className="card">
          <div className="card-head"><span className="card-icon">🔗</span>
            <div><div className="card-title">Upstream work product: {upName}</div><div className="card-sub">The {form.wp} should be based on the {upName}.</div></div>
          </div>
          {hasSession && (
            <label className="check"><input type="checkbox" checked={useSession} onChange={(e) => setUse(form.wp, e.target.checked)} />
              Use the {upName} generated in this session</label>
          )}
          {!useSession && (
            <FileDrop testId="drop-upstream" icon="📎" title={`Upload ${upName}`} subtitle={form.wp === 'Safety Goals' ? 'An .xlsx exported by this tool lets ASILs be taken from the HARA' : 'Excel, PDF, Word or text'}
              accept=".xlsx,.pdf,.docx,.txt,.md" multiple={false} files={form.upstreamFiles[form.wp] ? [form.upstreamFiles[form.wp]] : []}
              onChange={(fs) => updateForm({ upstreamFiles: { ...form.upstreamFiles, [form.wp]: fs[0] } })} />
          )}
          {form.wp === 'Safety Goals' && useSession && <div className="hint ok">✅ {Object.keys(sessionHeAsil).length} hazardous events with ASIL – safety goal ASILs will be computed from them.</div>}
          {!useSession && !form.upstreamFiles[form.wp] && <div className="hint">Recommended. Without it the {form.wp} is generated from the concept only.</div>}
        </div>
      )}

      <div className="card">
        <div className="card-head"><span className="card-icon">📝</span>
          <div><div className="card-title">Assumptions / Additional Information</div><div className="card-sub">Enter project-specific assumptions, operating conditions, standards, customer requirements, etc.</div></div>
        </div>
        <textarea className="area" rows={6} value={form.assumptions} onChange={(e) => updateForm({ assumptions: e.target.value })} placeholder={PLACEHOLDER} />
      </div>

      <details className="advanced">
        <summary>⚙️ Advanced Options</summary>
        <div className="grid-4">
          <label className="field"><span>Max rows per section</span>
            <input type="number" min={3} max={40} value={settings.maxRows} onChange={(e) => setSettings({ ...settings, maxRows: Number(e.target.value) })} /></label>
          <label className="field"><span>RAG chunks (top-k)</span>
            <input type="number" min={0} max={12} value={settings.topK} onChange={(e) => setSettings({ ...settings, topK: Number(e.target.value) })} /></label>
          <label className="field"><span>Temperature: {settings.temperature}</span>
            <input type="range" min={0} max={1} step={0.05} value={settings.temperature} onChange={(e) => setSettings({ ...settings, temperature: Number(e.target.value) })} /></label>
          <label className="check"><input type="checkbox" checked={settings.useEmbeddings} onChange={(e) => setSettings({ ...settings, useEmbeddings: e.target.checked })} />
            Use embeddings for RAG (off = keyword search)</label>
        </div>
        <div className="hint">Each input is cut to {settings.maxInputChars.toLocaleString()} characters to fit the model context (change in Settings).</div>
      </details>

      {error && <div className="alert">{error}</div>}

      {job ? (
        <div className="progress-card">
          <div className="progress-text">{job.text}</div>
          <div className="bar"><div style={{ width: `${Math.round(job.progress * 100)}%` }} /></div>
          <button className="btn ghost small" onClick={onStop}>■ Stop</button>
        </div>
      ) : (
        <>
          <label className="mode-toggle">
            <input type="checkbox" checked={settings.guided} onChange={(e) => setSettings({ ...settings, guided: e.target.checked })} />
            <span className="switch" />
            <span><b>Guided mode</b> – review, edit and accept each section before the next one is generated (recommended)</span>
          </label>
          <button className="btn primary big" onClick={onGenerate} disabled={busy}>
            ✨ Generate {form.wp} {settings.guided ? 'step by step' : ''} (Using RAG + {settings.model})
          </button>
        </>
      )}

      <div className="lib-head">
        <div><h3>📚 Reference Library (Used for RAG)</h3><p className="step-sub">Sample templates and guidelines used for content retrieval</p></div>
        <button className="btn ghost small" onClick={goLibrary}>Manage library →</button>
      </div>
      <div className="lib-cards">
        {Object.entries(CATEGORIES).map(([key, c]) => {
          const n = libDocs.filter((d) => d.category === key).length;
          return (
            <div key={key} className={`lib-card ${c.color}`}>
              <div className="lib-icon">{c.icon}</div>
              <div>
                <div className="card-title">{c.label}</div>
                <div className="card-sub">{n} document{n === 1 ? '' : 's'}</div>
                <ul>{c.bullets.map((b) => <li key={b}>{b}</li>)}</ul>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
