import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Sidebar from './components/Sidebar.jsx';
import Header from './components/Header.jsx';
import Home from './pages/Home.jsx';
import Review from './pages/Review.jsx';
import Library from './pages/Library.jsx';
import Settings from './pages/Settings.jsx';
import About from './pages/About.jsx';
import { loadSettings, saveSettings } from './settings.js';
import { OllamaClient } from './lib/ollama.js';
import { ReferenceLibrary } from './lib/rag.js';
import { idbStore } from './lib/db.js';
import { extractText, fileToBase64, isImage } from './lib/loaders.js';
import { WORK_PRODUCTS, acceptedContext, generateSection, heAsilMap, postprocess, retrieveRefs, toText } from './lib/workproducts.js';
import { validateSection } from './lib/validate.js';
import { readHaraMap } from './lib/upstream.js';

const EMPTY_FORM = { project: '', wp: 'Item Definition', conceptFiles: [], archFiles: [], archText: '', assumptions: '', upstreamFiles: {}, useSession: {} };
const today = () => new Date().toLocaleDateString('en-GB');

/*
 * results[wp] = {
 *   sections: { [sectionId]: rows[] },
 *   steps:    { [sectionId]: { status: 'locked'|'generating'|'review'|'accepted'|'error', validation, error } },
 *   inputs, refs, guided, meta
 * }
 */
export default function App() {
  const [page, setPage] = useState('Home');
  const [settings, setSettingsState] = useState(loadSettings);
  const [form, setForm] = useState(EMPTY_FORM);
  const [results, setResultsState] = useState({});
  const resultsRef = useRef({});
  const [lastInputs, setLastInputs] = useState(null);
  const [job, setJob] = useState(null);             // { progress, text } while preparing / batch generating
  const [error, setError] = useState('');
  const [libDocs, setLibDocs] = useState([]);
  const abortRef = useRef(null);

  const library = useMemo(() => new ReferenceLibrary(idbStore()), []);
  const client = useMemo(() => new OllamaClient({ baseUrl: settings.ollamaUrl, model: settings.model, temperature: settings.temperature, numCtx: settings.numCtx }), [settings]);
  const refreshLibrary = useCallback(() => library.list().then(setLibDocs).catch(() => setLibDocs([])), [library]);
  useEffect(() => { refreshLibrary(); }, [refreshLibrary]);

  const setSettings = (s) => { setSettingsState(s); saveSettings(s); };
  const updateForm = (patch) => setForm((f) => ({ ...f, ...patch }));

  // keep a ref in sync so async steps always see the latest state
  const commit = (wp, fn) => {
    const next = { ...resultsRef.current, [wp]: fn(resultsRef.current[wp]) };
    resultsRef.current = next;
    setResultsState(next);
  };
  const setStep = (wp, id, patch) => commit(wp, (r) => ({ ...r, steps: { ...r.steps, [id]: { ...r.steps[id], ...patch } } }));

  // ------------------------------------------------------------------ inputs
  async function prepareInputs(wp, signal) {
    const spec = WORK_PRODUCTS[wp];
    const lim = settings.maxInputChars;
    const reuse = lastInputs && !form.conceptFiles.length && form.useSession.reusePrev !== false;
    const concept = (await Promise.all(form.conceptFiles.map(async (f) => `[${f.name}]\n${await extractText(f)}`))).join('\n\n');
    const archParts = [form.archText];
    for (const f of form.archFiles) {
      if (isImage(f.name)) {
        if (settings.visionModel) {
          setJob({ progress: 0, text: `Reading diagram ${f.name} with ${settings.visionModel} …` });
          archParts.push(`[${f.name} – described by vision model]\n${await client.describeImage(await fileToBase64(f), settings.visionModel, signal)}`);
        }
      } else archParts.push(`[${f.name}]\n${await extractText(f)}`);
    }
    let files = [...form.conceptFiles, ...form.archFiles].map((f) => f.name);
    let conceptText = concept;
    if (reuse) {
      conceptText = conceptText || lastInputs.concept;
      if (!form.archFiles.length) archParts.push(lastInputs.architecture);
      if (!files.length) files = lastInputs.files;
    }
    let upstreamText = ''; let heAsil = {};
    if (spec.upstream) {
      const session = resultsRef.current[spec.upstream];
      const file = form.upstreamFiles[wp];
      if (session && form.useSession[wp] !== false) {
        upstreamText = toText(spec.upstream, session.sections);
        if (wp === 'Safety Goals') heAsil = heAsilMap(session.sections.hazardous_events);
      } else if (file) {
        upstreamText = await extractText(file);
        if (wp === 'Safety Goals' && file.name.toLowerCase().endsWith('.xlsx')) heAsil = await readHaraMap(await file.arrayBuffer());
        files.push(file.name);
      }
    }
    const inputs = {
      concept: conceptText.slice(0, lim),
      architecture: archParts.filter((p) => p && p.trim()).join('\n\n').slice(0, lim),
      upstream: upstreamText.slice(0, lim), upstreamName: spec.upstream,
      assumptions: form.assumptions.slice(0, 4000), heAsil,
    };
    return { inputs, files };
  }

  // ------------------------------------------------------------------ one step
  async function runStep(wp, index, revise = null) {
    const spec = WORK_PRODUCTS[wp];
    const section = spec.sections[index];
    const r = resultsRef.current[wp];
    const controller = new AbortController();
    abortRef.current = controller;
    const previous = r.sections[section.id];
    setStep(wp, section.id, { status: 'generating', error: '' });
    try {
      const accepted = acceptedContext(wp, r.sections, spec.sections.filter((s) => r.steps[s.id]?.status === 'accepted').map((s) => s.id));
      const rows = await generateSection({ wp, section, inputs: r.inputs, client, refs: r.refs, settings, signal: controller.signal, accepted, revise });
      commit(wp, (cur) => ({
        ...cur,
        sections: { ...cur.sections, [section.id]: rows },
        steps: { ...cur.steps, [section.id]: { status: 'review', validation: validateSection(wp, section, rows, cur.inputs), error: '' } },
      }));
      return true;
    } catch (e) {
      const stopped = e.name === 'AbortError';
      setStep(wp, section.id, { status: previous?.length ? 'review' : 'error', error: stopped ? 'Generation stopped.' : e.message || String(e) });
      return false;
    } finally {
      abortRef.current = null;
    }
  }

  // ------------------------------------------------------------------ start
  async function runGeneration() {
    const { wp } = form;
    const spec = WORK_PRODUCTS[wp];
    setError('');
    const reuse = lastInputs && !form.conceptFiles.length && form.useSession.reusePrev !== false;
    const hasUpstream = spec.upstream && (form.upstreamFiles[wp] || resultsRef.current[spec.upstream]);
    if (!form.conceptFiles.length && !form.archText.trim() && !reuse && !hasUpstream) {
      setError('Please upload a system concept / function description (or an upstream work product) first.');
      return;
    }
    const controller = new AbortController();
    abortRef.current = controller;
    setJob({ progress: 0, text: 'Reading input files …' });
    try {
      const { inputs, files } = await prepareInputs(wp, controller.signal);
      setJob({ progress: 0, text: 'Searching the reference library …' });
      const refs = await retrieveRefs({ wp, inputs, client, library, settings });
      commit(wp, () => ({
        sections: {}, inputs, refs, guided: settings.guided,
        steps: Object.fromEntries(spec.sections.map((s) => [s.id, { status: 'locked' }])),
        meta: { project: form.project, model: settings.model, topK: settings.topK, references: [...new Set(refs.map((x) => x.file))], inputs: files },
      }));
      setLastInputs({ concept: inputs.concept, architecture: inputs.architecture, files });
      setJob(null);
      setPage('Generate');
      if (settings.guided) {
        await runStep(wp, 0);
      } else {
        for (let i = 0; i < spec.sections.length; i++) if (!(await runStep(wp, i))) break;
      }
    } catch (e) {
      setError(e.name === 'AbortError' ? 'Generation stopped.' : e.message || String(e));
      setJob(null);
    } finally {
      abortRef.current = null;
    }
  }

  // ------------------------------------------------------------------ review actions
  const actions = {
    async accept(wp, id) {
      const spec = WORK_PRODUCTS[wp];
      commit(wp, (r) => ({
        ...r,
        sections: { ...r.sections, [id]: r.sections[id].map((row) => ({ ...row, review: `Accepted by user – ${today()}` })) },
        steps: { ...r.steps, [id]: { ...r.steps[id], status: 'accepted' } },
      }));
      const next = spec.sections.findIndex((s) => resultsRef.current[wp].steps[s.id].status === 'locked');
      if (next >= 0 && resultsRef.current[wp].guided) await runStep(wp, next);
    },
    regenerate: (wp, id) => runStep(wp, WORK_PRODUCTS[wp].sections.findIndex((s) => s.id === id)),
    applyChanges: (wp, id, request) => runStep(wp, WORK_PRODUCTS[wp].sections.findIndex((s) => s.id === id), { request, rows: resultsRef.current[wp].sections[id] }),
    editRows(wp, id, rows) {
      const section = WORK_PRODUCTS[wp].sections.find((s) => s.id === id);
      commit(wp, (r) => {
        const fixed = postprocess(wp, rows, r.inputs).map((row) => (r.steps[id].status === 'accepted' ? { ...row, review: 'Edited after acceptance – re-accept' } : row));
        return {
          ...r,
          sections: { ...r.sections, [id]: fixed },
          steps: { ...r.steps, [id]: { ...r.steps[id], status: 'review', validation: validateSection(wp, section, fixed, r.inputs) } },
        };
      });
    },
    stop: () => abortRef.current?.abort(),
  };

  function handleUseAsInput(wp, target) {
    setForm((f) => ({ ...f, wp: target, useSession: { ...f.useSession, [target]: true } }));
    setPage('Home');
  }

  const sessionHeAsil = results.HARA ? heAsilMap(results.HARA.sections.hazardous_events) : {};
  const busy = !!job || Object.values(results).some((r) => Object.values(r.steps).some((s) => s.status === 'generating'));

  return (
    <div className="layout">
      <Sidebar page={page} setPage={setPage} settings={settings} results={results} busy={busy} />
      <main className="main">
        <Header model={settings.model} />
        {page === 'Home' && (
          <Home form={form} updateForm={updateForm} settings={settings} setSettings={setSettings} job={job} error={error}
            onGenerate={runGeneration} onStop={() => abortRef.current?.abort()} results={results} lastInputs={lastInputs}
            libDocs={libDocs} goLibrary={() => setPage('Reference Library')} sessionHeAsil={sessionHeAsil} busy={busy} />
        )}
        {page === 'Generate' && <Review results={results} actions={actions} onUseAsInput={handleUseAsInput} goHome={() => setPage('Home')} />}
        {page === 'Reference Library' && <Library library={library} docs={libDocs} refresh={refreshLibrary} client={client} settings={settings} />}
        {page === 'Settings' && <Settings settings={settings} setSettings={setSettings} />}
        {page === 'About' && <About />}
      </main>
    </div>
  );
}
